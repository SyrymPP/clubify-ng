export interface IClub {
    name: string,
    category: string,
    desc: string,
    img: string,
    text: string
}